import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import static org.junit.Assert.assertEquals;

public class Form {
    public static void main(String[] args) throws InterruptedException {

        System.setProperty("webdriver.chrome.driver", "D:\\download\\chromedriver\\chromedriver.exe");

        WebDriver driver = new ChromeDriver();

        driver.get("https://feature-qa-automation.customer-frontend.staging.aspireapp.com/sg/");
        Thread.sleep(3000);

        LoginPage loginPage = new LoginPage();
        loginPage.submitLoginForm(driver);
        Thread.sleep(5000);

        MobileOTPPage mobileOTPPage = new MobileOTPPage();
        mobileOTPPage.submitOTP(driver);
        Thread.sleep(3000);

        BusinessRolePage businessRolePage = new BusinessRolePage();
        businessRolePage.submitBusinessRole(driver);
        Thread.sleep(5000);

        OnboardingNPSPage onboardingNPSPage = new OnboardingNPSPage();
        onboardingNPSPage.waitForOnboardingNPSAlert(driver);
        Thread.sleep(3000);

        assertEquals("We will be there soon!",onboardingNPSPage.getOnboardingNPSText(driver));

        driver.quit();
    }
}
