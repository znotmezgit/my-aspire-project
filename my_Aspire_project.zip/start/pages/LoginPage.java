import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class LoginPage {

        public void submitLoginForm(WebDriver driver) throws InterruptedException {

            driver.findElement(By.cssSelector("input[type='text']")).sendKeys("123456");
            Thread.sleep(3000);

            WebDriverWait wait = new WebDriverWait(driver, 10);

//            //Remember checkbox
//            driver.findElement(By.cssSelector(".q-checkbox__label.q-anchor--skip")).click();
//            Thread.sleep(2000);

            driver.findElement(By.cssSelector(".block")).click();
            Thread.sleep(3000);

            driver.findElement(By.cssSelector(".q-img__image.q-img__image--with-transition.q-img__image--loaded")).click();
            Thread.sleep(2000);

            wait.until((ExpectedConditions.visibilityOfElementLocated(By.cssSelector("div[role='listbox'] div:nth-child(4)"))));
            Thread.sleep(2000);

            driver.findElement(By.cssSelector("div[role='listbox'] div:nth-child(4)")).click();
            Thread.sleep(2000);

            driver.findElement(By.cssSelector("button[role='button'][type='button']")).click();
            Thread.sleep(2000);
    }

}
