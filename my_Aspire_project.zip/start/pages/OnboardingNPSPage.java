import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class OnboardingNPSPage {

    public static void waitForOnboardingNPSAlert(WebDriver driver) {

        WebDriverWait wait = new WebDriverWait(driver, 10);

        wait.until((ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[normalize-space()='We will be there soon!']"))));
    }

    public static String getOnboardingNPSText(WebDriver driver)
    {
        return driver.findElement(By.xpath("//div[normalize-space()='We will be there soon!']")).getText();
    }
}
