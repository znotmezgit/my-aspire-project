import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class BusinessRolePage {

    public void submitBusinessRole(WebDriver driver) throws InterruptedException {

        WebDriverWait wait = new WebDriverWait(driver, 10);

        Actions actions = new Actions(driver);

        wait.until((ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'I am a freelancer')]"))));
        Thread.sleep(2000);

        driver.findElement(By.xpath("//div[contains(text(),'I am a freelancer')]")).click();

        wait.until((ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id=\"q-app\"]/div/div/main/form/div[1]/div[1]/label/div/div/div[2]"))));
        Thread.sleep(2000);

        driver.findElement(By.xpath("//*[@id=\"q-app\"]/div/div/main/form/div[1]/div[1]/label/div/div/div[2]")).click();

        wait.until((ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'numquam')]"))));
        Thread.sleep(2000);

        driver.findElement(By.xpath("//div[contains(text(),'numquam')]")).click();
        Thread.sleep(2000);

        wait.until((ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id=\"q-app\"]/div/div/main/form/div[1]/div[1]/label/div/div/div[2]"))));
        Thread.sleep(2000);

        driver.findElement(By.xpath("//*[@id=\"q-app\"]/div/div/main/form/div[1]/div[1]/label/div/div/div[2]")).click();
        Thread.sleep(2000);

        wait.until((ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'Yes, I do')]"))));
        Thread.sleep(2000);

        driver.findElement(By.xpath("//div[contains(text(),'Yes, I do')]")).click();
        Thread.sleep(2000);

        wait.until((ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@isactiveoptionvisible='true']"))));
        driver.findElement(By.xpath("//div[@isactiveoptionvisible='true']")).click();
        Thread.sleep(2000);

        actions.sendKeys(Keys.chord(Keys.END)).perform();

        wait.until((ExpectedConditions.visibilityOfElementLocated(By.xpath("(//div[@role='option'])[23]"))));
        driver.findElement(By.xpath("(//div[@role='option'])[23]")).click();
        Thread.sleep(2000);

        driver.findElement(By.xpath("//span[@class='block']")).click();
        Thread.sleep(2000);
    }
}
