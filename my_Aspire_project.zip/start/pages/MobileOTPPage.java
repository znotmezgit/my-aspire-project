import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.interactions.Actions;

public class MobileOTPPage {

    public void submitOTP(WebDriver driver) {

        Actions act = new Actions(driver);
        act.moveToElement(driver.findElement(By.xpath("//div[@class='digit-input aspire-field']"))).sendKeys("1234").build().perform();

    }
}
